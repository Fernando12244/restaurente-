# Publicar cursos no GitHub sem Firebase Blaze

O painel grava os dados operacionais do curso no Firestore e também publica uma cópia do catálogo em `catalog/cursos.json`. Os vídeos, áudios e PDFs enviados pelo Admin entram em `media/cursos/{id}/{tipo}/` e o URL raw fica associado à aula para reprodução dentro do site.

## Criar o token

No GitHub, cria um **Fine-grained personal access token** com:

- Repository access: apenas `GOLANGUAGE202030`;
- Repository permissions: **Contents — Read and write**;
- Uma data de expiração curta que possas renovar.

A API REST do GitHub aceita pedidos CORS de aplicações web. Assim, este envio direto não precisa de Cloud Functions nem do plano Blaze.

## Usar

1. Publica a versão atualizada do site no Firebase Hosting pelo método que já usas.
2. No painel Admin, cria/edita cursos e preenche a descrição. Ao guardar, o catálogo é sincronizado.
3. Ao adicionar uma aula, seleciona vídeo, áudio ou PDF. Quando o site pedir, cola o token e confirma a branch correta (`main` se essa for a branch do repositório).
4. O token fica apenas na memória desta aba por 30 minutos; não é escrito no HTML, Firestore, localStorage ou GitHub. Fechar a página apaga-o.

O limite de upload no Admin é 50 MB por ficheiro. O repositório precisa estar público para os alunos reproduzirem os ficheiros. Conteúdos públicos podem ser acedidos por qualquer pessoa que obtenha o URL.

## Segurança

Esta opção não usa Blaze, mas o token passa pelo navegador durante a ligação ao GitHub e pode ser visto nas ferramentas do navegador. Usa um token exclusivo, limitado a este repositório e com expiração. Revoga-o nas definições do GitHub quando terminares de usar ou se suspeitares que foi exposto. Um backend com secret seria mais seguro, mas exigiria alojamento de backend.
