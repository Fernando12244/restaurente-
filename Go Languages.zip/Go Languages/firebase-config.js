// firebase-config.js
// Inicialização central do Firebase para o site Go Languages.
// Importado como módulo ES (<script type="module">) por login.html,
// registo.html, aluno.html e admin.html.

import { initializeApp } from "https://www.gstatic.com/firebasejs/12.8.0/firebase-app.js";
import { getAuth } from "https://www.gstatic.com/firebasejs/12.8.0/firebase-auth.js";
import { getFirestore, doc, getDoc, setDoc, onSnapshot, runTransaction, Bytes, collection, getDocs, query, where, writeBatch, serverTimestamp } from "https://www.gstatic.com/firebasejs/12.8.0/firebase-firestore.js";
import { criarControladorConsentimentoAnalytics } from './analytics-consent.mjs';
import { firebaseConfig } from './firebase-app-config.js';

// Apaga a cópia completa de dados privados deixada por versões anteriores.
try { localStorage.removeItem('gl_admin_v4'); } catch {}

export const app = initializeApp(firebaseConfig);
export const auth = getAuth(app);

// Analytics é carregado apenas após escolha explícita do utilizador.
export let analytics = null;
const COOKIE_CONSENT_KEY = 'gl_cookie_consent_v1';
const controladorAnalytics = criarControladorConsentimentoAnalytics({
  app,
  carregarSdk: () => import('https://www.gstatic.com/firebasejs/12.8.0/firebase-analytics.js'),
});
function consentimentoAnalytics() {
  try { return localStorage.getItem(COOKIE_CONSENT_KEY) === 'analytics'; } catch { return false; }
}
// Sincroniza a escolha guardada depois do default denied e antes de importar o SDK.
if (typeof window !== 'undefined') {
  window.goSchoolUpdateGoogleConsent?.(consentimentoAnalytics() ? 'analytics' : 'essential');
}
async function atualizarConsentimentoAnalytics(aceite = consentimentoAnalytics()) {
  try {
    await controladorAnalytics.actualizar(aceite ? 'analytics' : 'essential');
    analytics = controladorAnalytics.estado().instancia;
  } catch (erro) {
    analytics = null;
    console.warn('[Analytics] Não foi possível aplicar a preferência de privacidade.', erro);
  }
}
if (typeof window !== 'undefined') {
  window.addEventListener('gl:cookie-consent-change', event => {
    atualizarConsentimentoAnalytics(event.detail?.choice === 'analytics');
  });
  window.addEventListener('storage', event => {
    if (event.key === COOKIE_CONSENT_KEY) atualizarConsentimentoAnalytics(event.newValue === 'analytics');
  });
}
if (consentimentoAnalytics()) atualizarConsentimentoAnalytics(true);

// Firestore: base de dados na nuvem partilhada por todos os dispositivos.
export const db = getFirestore(app);
const TAMANHO_PARTE_PDF = 640 * 1024; // cada parte fica abaixo do limite de 1 MiB do Firestore

export async function enviarManualPdfCurso(file, cursoId, onProgress = () => {}) {
  if (!file || file.type !== 'application/pdf') throw new Error('Seleciona um ficheiro PDF válido.');
  if (file.size > 20 * 1024 * 1024) throw new Error('O manual PDF não pode exceder 20 MB.');
  const nome = String(file.name || 'manual.pdf').normalize('NFKD').replace(/[\u0300-\u036f]/g, '').replace(/[^a-zA-Z0-9._-]+/g, '-').slice(0,100) || 'manual.pdf';
  const curso = String(cursoId);
  const arquivoId = Date.now().toString(36) + Math.random().toString(36).slice(2,8);
  const dados = new Uint8Array(await file.arrayBuffer());
  const totalPartes = Math.ceil(dados.length / TAMANHO_PARTE_PDF);
  const raiz = doc(db, 'manuaisCursos', curso, 'arquivos', arquivoId);
  await setDoc(raiz, { nome, tamanho: file.size, contentType: 'application/pdf', totalPartes, estado: 'a-enviar', criadoEm: new Date().toISOString() });
  let concluidas = 0;
  for (let inicio = 0; inicio < totalPartes; inicio += 8) {
    const indices = Array.from({length: Math.min(8, totalPartes - inicio)}, (_, i) => inicio + i);
    await Promise.all(indices.map(async indice => {
      const parte = dados.subarray(indice * TAMANHO_PARTE_PDF, Math.min((indice + 1) * TAMANHO_PARTE_PDF, dados.length));
      await setDoc(doc(db, 'manuaisCursos', curso, 'arquivos', arquivoId, 'partes', String(indice).padStart(5, '0')), { bytes: Bytes.fromUint8Array(parte) });
      concluidas++;
      onProgress(Math.round(concluidas / totalPartes * 100));
    }));
  }
  await setDoc(raiz, { estado: 'pronto' }, { merge: true });
  return { id: arquivoId, nome, tamanho: file.size, totalPartes };
}

export async function carregarManualPdfCurso(cursoId, arquivoId) {
  const curso = String(cursoId), id = String(arquivoId);
  const raiz = doc(db, 'manuaisCursos', curso, 'arquivos', id);
  const metaSnap = await getDoc(raiz);
  if (!metaSnap.exists() || metaSnap.data().estado !== 'pronto') throw new Error('Este manual ainda não está disponível.');
  const meta = metaSnap.data(), partes = [];
  for (let inicio = 0; inicio < meta.totalPartes; inicio += 8) {
    const indices = Array.from({length: Math.min(8, meta.totalPartes - inicio)}, (_, i) => inicio + i);
    const snapshots = await Promise.all(indices.map(indice => getDoc(doc(db, 'manuaisCursos', curso, 'arquivos', id, 'partes', String(indice).padStart(5, '0')))));
    for (const snap of snapshots) {
      if (!snap.exists() || !snap.data().bytes) throw new Error('Uma parte do manual não foi encontrada. Tenta novamente.');
      partes.push(snap.data().bytes.toUint8Array());
    }
  }
  return { blob: new Blob(partes, {type:'application/pdf'}), nome: meta.nome || 'manual.pdf' };
}

export async function concederAcessoManual(alunoEmail, cursoId) {
  const email = String(alunoEmail || '').trim().toLowerCase();
  if (!email || !cursoId) return;
  await setDoc(doc(db, 'acessosManuais', String(cursoId), 'alunos', email), { ativo: true, atualizadoEm: new Date().toISOString() }, { merge: true });
}

const DOC_DADOS_ADMIN = doc(db, "admin", "dados");
const DOC_CONFIG_PUBLICA = doc(db, 'public', 'config');

function projetarDadosPublicos(dados = {}) {
  const camposPublicos = ['id', 'nome', 'descricao', 'preco', 'img', 'modulos', 'tipoConteudo', 'estado', 'manualId'];
  const camposProfessor = ['id', 'nome', 'bio', 'foto', 'idiomas', 'niveis', 'tipo', 'horarios', 'experiencia', 'especialidade'];
  const camposPlano = ['id', 'nome', 'cursoId', 'modalidade', 'valorMensal', 'limiteAlunos', 'professorId', 'professorNome', 'plataforma', 'diasSemana', 'aulasPorDia', 'duracaoAula', 'horaInicio', 'dataInicio', 'estado'];
  const selecionar = (items, campos) => (Array.isArray(items) ? items : []).map(item => Object.fromEntries(campos.filter(k => item?.[k] !== undefined).map(k => [k, item[k]])));
  const ocupacaoTurma = (planoId) => (Array.isArray(dados.agendamentos) ? dados.agendamentos : []).filter(a => String(a.planoId) === String(planoId) && !['cancelada','recusada','recusado'].includes(a.estado) && a.pagamentoEstado !== 'recusado').length;
  const planosPublicos = selecionar(dados.planos, camposPlano).map(plano => {
    if (plano.modalidade !== 'team') return plano;
    const limite = Math.max(1, Number(plano.limiteAlunos) || 5);
    const ocupados = ocupacaoTurma(plano.id);
    return { ...plano, lugaresOcupados: ocupados, vagasRestantes: Math.max(0, limite - ocupados) };
  });
  return {
    schemaVersion: 1,
    atualizadoEm: new Date().toISOString(),
    cursos: selecionar(dados.cursos, camposPublicos),
    professores: selecionar(dados.professores, camposProfessor),
    planos: planosPublicos,
    configOnline: dados.configOnline && typeof dados.configOnline === 'object' ? {
      privateNome: dados.configOnline.privateNome || '', privateDescricao: dados.configOnline.privateDescricao || '', privatePreco: Number(dados.configOnline.privatePreco) || 0,
      teamNome: dados.configOnline.teamNome || '', teamDescricao: dados.configOnline.teamDescricao || '', teamPreco: Number(dados.configOnline.teamPreco) || 0,
      faqPlanos: String(dados.configOnline.faqPlanos || '').slice(0, 600), faqPagamento: String(dados.configOnline.faqPagamento || '').slice(0, 600),
      faqNiveis: String(dados.configOnline.faqNiveis || '').slice(0, 600), faqHorarios: String(dados.configOnline.faqHorarios || '').slice(0, 600),
      faqPlataforma: String(dados.configOnline.faqPlataforma || '').slice(0, 600),
      politicaOperacional: String(dados.configOnline.politicaOperacional || '').slice(0, 1200),
      domicilioDescricao: String(dados.configOnline.domicilioDescricao || '').slice(0, 400),
      limiteEstatisticas: Math.max(1, Number(dados.configOnline.limiteEstatisticas) || 20),
      alunosPublicos: Math.max(0, Number(dados.configOnline.alunosPublicos) || 0),
      publicarTestemunhos: dados.configOnline.publicarTestemunhos === true,
    } : {},
    whatsapp: { numero: dados.whatsapp?.numero || '', numeroSecundario: dados.whatsapp?.numeroSecundario || '' },
    avaliacoesCursos: selecionar(dados.avaliacoesCursos, ['cursoId', 'nota']),
    avaliacoesProfessores: selecionar(dados.avaliacoesProfessores, ['professorId', 'nota']),
    depoimentos: dados.configOnline?.publicarTestemunhos === true
      ? [...(Array.isArray(dados.avaliacoesCursos) ? dados.avaliacoesCursos : []), ...(Array.isArray(dados.avaliacoesProfessores) ? dados.avaliacoesProfessores : [])]
        .filter(item => item?.autorizacaoPublica === true && item?.publicarNoSite === true && String(item.comentario || '').trim().length >= 8 && Number(item.nota) >= 1 && Number(item.nota) <= 5)
        .map(item => ({ nome: String(item.alunoNome || 'Aluno').trim().split(/\s+/)[0], comentario: String(item.comentario).trim().slice(0, 500), nota: Number(item.nota) }))
      : [],
  };
}

export async function carregarDadosPublicos() {
  const snap = await getDoc(DOC_CONFIG_PUBLICA);
  return snap.exists() ? snap.data() : null;
}

export function subscreverDadosPublicos(callback, onError) {
  return onSnapshot(DOC_CONFIG_PUBLICA, snap => callback(snap.exists() ? snap.data() : null), onError);
}

// Lê o documento único com todos os dados do painel de admin.
// Devolve `null` se ainda não existir nenhum documento na nuvem.
// Apenas contas com a custom claim de administrador podem carregar estes dados.
export async function carregarDadosAdmin() {
  await assertAdmin();
  const [snap, estudantesSnap, reservasSnap, pedidosSnap] = await Promise.all([
    getDoc(DOC_DADOS_ADMIN), getDocs(collection(db, 'students')),
    getDocs(collection(db, 'bookings')), getDocs(collection(db, 'requests')),
  ]);
  if (!snap.exists()) return null;
  const dados = snap.data();
  dados.alunos = Array.isArray(dados.alunos) ? dados.alunos : [];
  for (const estudanteDoc of estudantesSnap.docs) {
    const estudante = estudanteDoc.data();
    const indice = dados.alunos.findIndex(a => a.uid === estudanteDoc.id || (a.email || '').toLowerCase() === (estudante.email || '').toLowerCase());
    if (indice >= 0) dados.alunos[indice] = { ...dados.alunos[indice], ...estudante, uid: estudanteDoc.id };
    else dados.alunos.push({ ...estudante, uid: estudanteDoc.id });
  }
  const reservas = new Map((Array.isArray(dados.agendamentos) ? dados.agendamentos : []).map(a => [String(a.id), a]));
  for (const item of reservasSnap.docs) reservas.set(String(item.data().id || item.id), { ...item.data(), id: item.data().id || item.id });
  dados.agendamentos = [...reservas.values()];
  dados.pedidos = Array.isArray(dados.pedidos) ? dados.pedidos : [];
  dados.solicitacoesDomicilio = Array.isArray(dados.solicitacoesDomicilio) ? dados.solicitacoesDomicilio : [];
  for (const item of pedidosSnap.docs) {
    const pedido = { ...item.data(), id: item.data().id || item.id };
    const lista = pedido.tipo === 'domicilio' ? dados.solicitacoesDomicilio : dados.pedidos;
    const indice = lista.findIndex(p => String(p.id) === String(pedido.id));
    if (indice >= 0) lista[indice] = { ...lista[indice], ...pedido };
    else lista.push(pedido);
  }
  return dados;
}

async function sincronizarColecoesAdmin(dados) {
  const estudantesSnap = await getDocs(collection(db, 'students'));
  const uidPorEmail = new Map(estudantesSnap.docs.map(s => [(s.data().email || '').toLowerCase(), s.id]));
  for (const aluno of (dados.alunos || [])) if (aluno.uid && aluno.email) uidPorEmail.set(aluno.email.toLowerCase(), aluno.uid);
  const writes = [];
  for (const aluno of (dados.alunos || [])) {
    const uid = aluno.uid || uidPorEmail.get((aluno.email || '').toLowerCase());
    if (!uid) continue;
    writes.push([doc(db, 'students', uid), { ...aluno, uid, email: (aluno.email || '').toLowerCase() }]);
  }
  for (const reserva of (dados.agendamentos || [])) {
    const uid = reserva.uid || uidPorEmail.get((reserva.alunoEmail || '').toLowerCase());
    if (!uid || reserva.id == null) continue;
    writes.push([doc(db, 'bookings', encodeURIComponent(String(reserva.id))), { ...reserva, uid }]);
  }
  for (const [tipo, lista] of [['compra', dados.pedidos || []], ['domicilio', dados.solicitacoesDomicilio || []]]) {
    for (const pedido of lista) {
      const uid = pedido.uid || uidPorEmail.get((pedido.alunoEmail || '').toLowerCase());
      if (!uid || pedido.id == null) continue;
      writes.push([doc(db, 'requests', encodeURIComponent(`${tipo}-${pedido.id}`)), { ...pedido, tipo, uid }]);
    }
  }
  for (let inicio = 0; inicio < writes.length; inicio += 400) {
    const batch = writeBatch(db);
    for (const [ref, value] of writes.slice(inicio, inicio + 400)) batch.set(ref, value);
    await batch.commit();
  }
}

async function assertAdmin() {
  await auth.authStateReady();
  const user = auth.currentUser;
  if (!user) throw Object.assign(new Error('Sessão Firebase necessária.'), { code: 'unauthenticated' });
  const token = await user.getIdTokenResult();
  if (token.claims.admin !== true) throw Object.assign(new Error('Apenas um administrador pode aceder a estes dados.'), { code: 'permission-denied' });
  return user;
}

export async function guardarPerfilAluno({ nome, email, telefone = '', consentimentos }) {
  await auth.authStateReady();
  const user = auth.currentUser;
  if (!user || !user.email || user.email.toLowerCase() !== String(email || '').trim().toLowerCase()) {
    throw Object.assign(new Error('A sessão não corresponde ao perfil do aluno.'), { code: 'permission-denied' });
  }
  const ref = doc(db, 'students', user.uid);
  const atual = await getDoc(ref);
  const perfil = atual.exists() ? atual.data() : {};
  const timestampServidor = serverTimestamp();
  const novoConsentimento = {
    termos: { aceite: consentimentos?.termos?.aceite === true, versao: '2026-10-14', aceiteEm: timestampServidor },
    privacidade: { aceite: consentimentos?.privacidade?.aceite === true, versao: '2026-10-14', aceiteEm: timestampServidor },
    marketing: {
      aceite: consentimentos?.marketing === true,
      versao: 'marketing-v1',
      aceiteEm: consentimentos?.marketing === true ? timestampServidor : null,
    },
    menorDeIdade: consentimentos?.menorDeIdade === true,
    encarregado: consentimentos?.menorDeIdade === true ? {
      nome: String(consentimentos.encarregado?.nome || '').trim(),
      parentesco: String(consentimentos.encarregado?.parentesco || '').trim(),
      telefone: String(consentimentos.encarregado?.telefone || '').trim(),
      email: String(consentimentos.encarregado?.email || '').trim().toLowerCase(),
      autorizou: consentimentos.encarregado?.autorizou === true,
      autorizouEm: timestampServidor,
    } : null,
    registadoEm: timestampServidor,
  };
  const consentimentoAnteriorValido = perfil.consentimentos?.termos?.aceite === true
    && perfil.consentimentos?.privacidade?.aceite === true;
  if (!consentimentoAnteriorValido && (!novoConsentimento.termos.aceite || !novoConsentimento.privacidade.aceite)) {
    throw Object.assign(new Error('É necessário aceitar os Termos de Uso e a Política de Privacidade.'), { code: 'permission-denied' });
  }
  if (novoConsentimento.menorDeIdade && (!novoConsentimento.encarregado.nome || !novoConsentimento.encarregado.parentesco || !novoConsentimento.encarregado.telefone || !novoConsentimento.encarregado.autorizou)) {
    throw Object.assign(new Error('Faltam os dados ou a autorização do encarregado de educação.'), { code: 'permission-denied' });
  }
  await setDoc(ref, {
    ...perfil,
    uid: user.uid,
    email: user.email.toLowerCase(),
    nome: String(nome || user.displayName || 'Aluno').trim(),
    telefone: String(telefone || ''),
    consentimentos: consentimentoAnteriorValido ? perfil.consentimentos : novoConsentimento,
    atualizadoEm: new Date().toISOString(),
    ...(perfil.criadoEm ? {} : { criadoEm: new Date().toISOString() }),
  });
}

export async function carregarDadosAluno() {
  await auth.authStateReady();
  const user = auth.currentUser;
  if (!user) throw Object.assign(new Error('Inicia sessão para carregar o teu perfil.'), { code: 'unauthenticated' });
  const [publicos, perfilSnap, reservasSnap, pedidosSnap] = await Promise.all([
    carregarDadosPublicos(),
    getDoc(doc(db, 'students', user.uid)),
    getDocs(query(collection(db, 'bookings'), where('uid', '==', user.uid))),
    getDocs(query(collection(db, 'requests'), where('uid', '==', user.uid))),
  ]);
  const perfil = perfilSnap.exists() ? perfilSnap.data() : { uid: user.uid, email: (user.email || '').toLowerCase(), nome: user.displayName || 'Aluno' };
  const pedidos = pedidosSnap.docs.map(s => ({ id: s.id, ...s.data() }));
  return {
    ...(publicos || {}),
    admin: {}, alunos: [perfil],
    agendamentos: reservasSnap.docs.map(s => ({ id: s.id, ...s.data() })),
    pedidos: pedidos.filter(p => p.tipo === 'compra'),
    solicitacoesDomicilio: pedidos.filter(p => p.tipo === 'domicilio'),
    notificacoes: Array.isArray(perfil.notificacoes) ? perfil.notificacoes : [],
    vendas: [], pagamentoManual: {},
  };
}

export async function atualizarDadosAluno(mutador) {
  const user = auth.currentUser;
  if (!user) throw Object.assign(new Error('Inicia sessão para guardar alterações.'), { code: 'unauthenticated' });
  const atuais = await carregarDadosAluno();
  const novos = mutador(atuais) || atuais;
  const mapear = lista => new Map((lista || []).map(item => [String(item.id), item]));
  for (const [antes, depois, tipo] of [
    [atuais.agendamentos, novos.agendamentos, 'reserva'],
    [[...atuais.pedidos, ...atuais.solicitacoesDomicilio], [...(novos.pedidos || []), ...(novos.solicitacoesDomicilio || [])], 'pedido'],
  ]) {
    const antigos = mapear(antes), recentes = mapear(depois);
    for (const [id, item] of antigos) {
      if (recentes.has(id) && JSON.stringify(recentes.get(id)) !== JSON.stringify(item)) {
        throw new Error(`Não podes alterar diretamente um ${tipo} existente. Solicita a alteração à administração.`);
      }
    }
  }
  const perfil = (novos.alunos || []).find(a => (a.email || '').toLowerCase() === (user.email || '').toLowerCase()) || {};
  const perfilRef = doc(db, 'students', user.uid);
  const perfilSnap = await getDoc(perfilRef);
  const antigoPerfil = perfilSnap.exists() ? perfilSnap.data() : {};
  const camposPerfil = ['nome', 'telefone', 'foto', 'morada', 'preferencias', 'notificacoesLidas', 'progresso'];
  const perfilGuardado = Object.fromEntries(camposPerfil.filter(k => perfil[k] !== undefined).map(k => [k, perfil[k]]));
  await setDoc(perfilRef, {
    ...antigoPerfil, ...perfilGuardado, uid: user.uid,
    email: (user.email || '').toLowerCase(), atualizadoEm: new Date().toISOString(),
  });

  const reservasAnteriores = new Set(atuais.agendamentos.map(a => String(a.id)));
  for (const reserva of (novos.agendamentos || [])) {
    if (reservasAnteriores.has(String(reserva.id))) continue;
    const estadoPagamento = String(reserva.pagamentoEstado || '').toLowerCase();
    if (!['pendente', 'aguarda_liberacao'].includes(estadoPagamento)) throw new Error('A reserva não pode ser criada com um estado de pagamento confirmado.');
    const id = encodeURIComponent(String(reserva.id));
    await setDoc(doc(db, 'bookings', id), { ...reserva, uid: user.uid, pagamentoEstado: estadoPagamento });
  }
  const pedidosAnteriores = new Set([...atuais.pedidos, ...atuais.solicitacoesDomicilio].map(p => `${p.tipo}:${p.id}`));
  for (const [tipo, lista] of [['compra', novos.pedidos || []], ['domicilio', novos.solicitacoesDomicilio || []]]) {
    for (const pedido of lista) {
      if (pedidosAnteriores.has(`${tipo}:${pedido.id}`)) continue;
      const id = encodeURIComponent(`${tipo}-${pedido.id}`);
      await setDoc(doc(db, 'requests', id), { ...pedido, tipo, uid: user.uid, estado: 'pendente' });
    }
  }
  return novos;
}

// Grava (substitui por completo) os dados do painel de admin na nuvem.
export async function guardarDadosAdmin(dados) {
  await assertAdmin();
  await setDoc(DOC_DADOS_ADMIN, dados);
  await setDoc(DOC_CONFIG_PUBLICA, projetarDadosPublicos(dados));
  await sincronizarColecoesAdmin(dados);
}

// Subscreve alterações em tempo real (ex.: outro dispositivo/aba a editar
// os mesmos dados). `callback` recebe o objeto de dados mais recente.
// Esta subscrição transmite apenas dados ao painel administrativo autenticado.
// Devolve a função de "unsubscribe".
export function subscreverDadosAdmin(callback, onError = (erro) => {
  console.error('[Firestore] subscrição interrompida:', erro);
}) {
  return onSnapshot(DOC_DADOS_ADMIN, (snap) => {
    if (snap.exists()) {
      callback(snap.data());
    }
  }, onError);
}

const DADOS_VAZIOS = {
  admin: { nome: 'Admin', email: 'admin@golanguages.com', telefone: '', foto: '' },
  professores: [], cursos: [], alunos: [], vendas: [], notificacoes: [],
  avaliacoesProfessores: [], avaliacoesCursos: [], agendamentos: [],
};

// Aplica uma alteração aos dados do admin de forma segura, mesmo que várias
// páginas (registo, checkout, aluno...) escrevam ao mesmo tempo: lê o
// documento mais recente, aplica `mutador` sobre ele e grava tudo de novo
// dentro de uma transação, para nunca perder alterações concorrentes.
// A custom claim e as regras Firestore impedem que alunos usem esta operação.
export async function atualizarDadosAdmin(mutador) {
  await assertAdmin();
  const resultado = await runTransaction(db, async (tx) => {
    const snap = await tx.get(DOC_DADOS_ADMIN);
    const atuais = snap.exists() ? snap.data() : structuredClone(DADOS_VAZIOS);
    const novos = mutador(atuais) || atuais;
    tx.set(DOC_DADOS_ADMIN, novos);
    return novos;
  });
  await setDoc(DOC_CONFIG_PUBLICA, projetarDadosPublicos(resultado));
  await sincronizarColecoesAdmin(resultado);
  return resultado;
}

// Traduz os códigos de erro do Firebase Auth para mensagens em português.
export function traduzirErroFirebase(codigo) {
  const mapa = {
    "auth/invalid-email": "E-mail inválido.",
    "auth/user-disabled": "Esta conta foi desativada.",
    "auth/user-not-found": "E-mail ou palavra-passe incorretos.",
    "auth/wrong-password": "E-mail ou palavra-passe incorretos.",
    "auth/invalid-credential": "E-mail ou palavra-passe incorretos.",
    "auth/invalid-login-credentials": "E-mail ou palavra-passe incorretos.",
    "auth/too-many-requests": "Demasiadas tentativas. Aguarde um momento e tente novamente.",
    "auth/network-request-failed": "Falha de rede. Verifique a sua ligação à internet.",
    "auth/email-already-in-use": "Já existe uma conta com este e-mail. Faça login.",
    "auth/weak-password": "A palavra-passe deve ter pelo menos 6 caracteres.",
    "auth/operation-not-allowed": "Login por e-mail/palavra-passe não está ativado no projeto Firebase.",
    "auth/missing-password": "Introduza a sua palavra-passe.",
    "auth/popup-blocked": "O seu navegador bloqueou a janela do Google. Permita pop-ups e tente novamente.",
    "auth/unauthorized-domain": "Este domínio não está autorizado no Firebase para login com Google.",
    "auth/account-exists-with-different-credential": "Já existe uma conta com este e-mail. Inicie sessão com a palavra-passe.",
  };
  return mapa[codigo] || "Ocorreu um erro. Tente novamente.";
}
