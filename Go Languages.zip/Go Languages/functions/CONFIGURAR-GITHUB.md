# Integração anterior: Firebase Functions

Este fluxo com Firebase Functions foi substituído pela ligação direta do Admin à API do GitHub para permitir sincronizar sem o plano Blaze. Não configurar nem publicar esta pasta.

Segue o guia atualizado em `GITHUB-SEM-BLAZE.md` na raiz do projeto.
