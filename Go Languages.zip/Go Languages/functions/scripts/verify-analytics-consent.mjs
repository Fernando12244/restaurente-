import assert from 'node:assert/strict';
import { criarControladorConsentimentoAnalytics } from '../../analytics-consent.mjs';

const chamadas = { carregar: 0, get: 0, enabled: [], reset: 0 };
const analyticsFalso = { id: 'analytics-instance' };
const sdkFalso = {
  isSupported: async () => true,
  getAnalytics: app => {
    assert.equal(app.id, 'test-app');
    chamadas.get += 1;
    return analyticsFalso;
  },
  setAnalyticsCollectionEnabled: (instance, enabled) => {
    assert.equal(instance, analyticsFalso);
    chamadas.enabled.push(enabled);
  },
  resetAnalyticsData: instance => {
    assert.equal(instance, analyticsFalso);
    chamadas.reset += 1;
  },
};

const controlador = criarControladorConsentimentoAnalytics({
  app: { id: 'test-app' },
  carregarSdk: async () => {
    chamadas.carregar += 1;
    return sdkFalso;
  },
});

await controlador.actualizar(null);
assert.deepEqual(controlador.estado(), { carregado: false, activo: false, instancia: null });
assert.equal(chamadas.carregar, 0, 'sem escolha explícita o SDK não deve ser carregado');

await controlador.actualizar('essential');
assert.equal(chamadas.carregar, 0, 'só essenciais não deve carregar o SDK');

await controlador.actualizar('analytics');
assert.equal(chamadas.carregar, 1, 'Analytics deve carregar após aceitação explícita');
assert.deepEqual(chamadas.enabled, [true]);
assert.equal(controlador.estado().activo, true);

await controlador.actualizar('essential');
assert.deepEqual(chamadas.enabled, [true, false], 'retirada deve desactivar recolha');
assert.equal(chamadas.reset, 1, 'retirada deve repor identificadores locais do Analytics');
assert.equal(controlador.estado().instancia, null);
assert.equal(controlador.estado().activo, false);

await controlador.actualizar('analytics');
assert.equal(chamadas.carregar, 1, 'reconsentimento reutiliza o SDK já carregado');
assert.equal(chamadas.get, 2, 'uma nova instância pode ser criada após a reposição local');
assert.equal(controlador.estado().activo, true);

console.log('Consentimento Analytics verificado: por defeito bloqueado, activado apenas após aceitação e desactivado após retirada.');
