const { applicationDefault, initializeApp } = require('firebase-admin/app');
const { getAuth } = require('firebase-admin/auth');
const { getFirestore } = require('firebase-admin/firestore');

initializeApp({ credential: applicationDefault(), projectId: process.env.GCLOUD_PROJECT || 'go-language0' });
const db = getFirestore();

const pick = (items, fields) => (Array.isArray(items) ? items : []).map(item => Object.fromEntries(fields.filter(k => item?.[k] !== undefined).map(k => [k, item[k]])));
const publicProjection = d => ({
  schemaVersion: 1,
  atualizadoEm: new Date().toISOString(),
  cursos: pick(d.cursos, ['id', 'nome', 'descricao', 'preco', 'img', 'modulos', 'tipoConteudo', 'estado', 'manualId']),
  professores: pick(d.professores, ['id', 'nome', 'bio', 'foto', 'idiomas', 'tipo', 'horarios', 'experiencia', 'especialidade']),
  planos: pick(d.planos, ['id', 'nome', 'cursoId', 'modalidade', 'valorMensal', 'limiteAlunos', 'professorId', 'professorNome', 'plataforma', 'diasSemana', 'aulasPorDia', 'duracaoAula', 'horaInicio', 'dataInicio', 'estado']),
  configOnline: {
    privateNome: d.configOnline?.privateNome || '', privateDescricao: d.configOnline?.privateDescricao || '', privatePreco: Number(d.configOnline?.privatePreco) || 0,
    teamNome: d.configOnline?.teamNome || '', teamDescricao: d.configOnline?.teamDescricao || '', teamPreco: Number(d.configOnline?.teamPreco) || 0,
  },
  whatsapp: { numero: d.whatsapp?.numero || '', numeroSecundario: d.whatsapp?.numeroSecundario || '' },
  avaliacoesCursos: pick(d.avaliacoesCursos, ['cursoId', 'nota']),
  avaliacoesProfessores: pick(d.avaliacoesProfessores, ['professorId', 'nota']),
});

async function main() {
  const root = await db.doc('admin/dados').get();
  if (!root.exists) throw new Error('O documento admin/dados não existe; não há dados para migrar.');
  const dados = root.data();
  const usersByEmail = new Map();
  let pageToken;
  do {
    const page = await getAuth().listUsers(1000, pageToken);
    for (const user of page.users) if (user.email) usersByEmail.set(user.email.toLowerCase(), user.uid);
    pageToken = page.pageToken;
  } while (pageToken);

  const ops = [];
  const uidByEmail = new Map();
  for (const aluno of dados.alunos || []) {
    const email = String(aluno.email || '').trim().toLowerCase();
    const uid = usersByEmail.get(email) || aluno.uid;
    if (!uid || !email) continue;
    uidByEmail.set(email, uid);
    ops.push([db.doc(`students/${uid}`), { ...aluno, uid, email }]);
  }
  const reservas = new Map((dados.agendamentos || []).map(a => [String(a.id), a]));
  for (const aluno of dados.alunos || []) {
    for (const reserva of aluno.agendamentos || []) if (reserva?.id != null) reservas.set(String(reserva.id), { ...reserva, alunoEmail: reserva.alunoEmail || aluno.email });
  }
  for (const reserva of reservas.values()) {
    const uid = reserva.uid || uidByEmail.get(String(reserva.alunoEmail || '').toLowerCase());
    if (uid && reserva.id != null) ops.push([db.doc(`bookings/${encodeURIComponent(String(reserva.id))}`), { ...reserva, uid }]);
  }
  for (const [tipo, rows] of [['compra', dados.pedidos || []], ['domicilio', dados.solicitacoesDomicilio || []]]) {
    for (const pedido of rows) {
      const uid = pedido.uid || uidByEmail.get(String(pedido.alunoEmail || '').toLowerCase());
      if (uid && pedido.id != null) ops.push([db.doc(`requests/${encodeURIComponent(`${tipo}-${pedido.id}`)}`), { ...pedido, tipo, uid }]);
    }
  }
  for (let offset = 0; offset < ops.length; offset += 400) {
    const batch = db.batch();
    for (const [ref, value] of ops.slice(offset, offset + 400)) batch.set(ref, value, { merge: true });
    await batch.commit();
  }
  await db.doc('public/config').set(publicProjection(dados));
  console.log(`Migração concluída: ${uidByEmail.size} perfis associados, ${ops.length - uidByEmail.size} registos privados e catálogo público projetado.`);
  console.log('O documento legado admin/dados foi mantido e está agora protegido por custom claim.');
}

main().catch(error => {
  console.error('Migração falhou:', error.message);
  process.exitCode = 1;
});
