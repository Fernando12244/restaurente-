const { applicationDefault, initializeApp } = require('firebase-admin/app');
const { getAuth } = require('firebase-admin/auth');

const email = String(process.argv[2] || '').trim().toLowerCase();
if (!email || !email.includes('@')) {
  console.error('Uso: node scripts/set-admin-claim.js admin@dominio.ao');
  process.exit(1);
}

initializeApp({ credential: applicationDefault(), projectId: process.env.GCLOUD_PROJECT || 'go-language0' });

async function main() {
  const auth = getAuth();
  const user = await auth.getUserByEmail(email);
  await auth.setCustomUserClaims(user.uid, { ...(user.customClaims || {}), admin: true });
  console.log(`Claim admin atribuída à conta ${email} (UID ${user.uid}).`);
  console.log('A conta deve terminar e iniciar sessão novamente para receber a nova claim.');
}

main().catch((error) => {
  console.error('Não foi possível atribuir a claim admin:', error.message);
  process.exitCode = 1;
});
