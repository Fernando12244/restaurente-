import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import vm from 'node:vm';

const source = await readFile(new URL('../../google-consent-mode.js', import.meta.url), 'utf8');
const window = {};
vm.runInNewContext(source, { window });

const commands = window.dataLayer.map(args => Array.from(args));
assert.equal(commands.length, 1, 'o script só deve inicializar o Consent Mode, sem pedir Analytics');
assert.deepEqual(JSON.parse(JSON.stringify(commands[0])), [
  'consent', 'default', {
    ad_storage: 'denied',
    ad_user_data: 'denied',
    ad_personalization: 'denied',
    analytics_storage: 'denied',
  },
]);

window.goSchoolUpdateGoogleConsent('analytics');
window.goSchoolUpdateGoogleConsent('essential');
const updates = window.dataLayer.slice(1).map(args => Array.from(args));
assert.equal(updates.length, 2);
assert.deepEqual(JSON.parse(JSON.stringify(updates[0])), [
  'consent', 'update', {
    ad_storage: 'denied',
    ad_user_data: 'denied',
    ad_personalization: 'denied',
    analytics_storage: 'granted',
  },
]);
assert.deepEqual(JSON.parse(JSON.stringify(updates[1])), [
  'consent', 'update', {
    ad_storage: 'denied',
    ad_user_data: 'denied',
    ad_personalization: 'denied',
    analytics_storage: 'denied',
  },
]);

console.log('Google Consent Mode v2 verificado: tudo negado por defeito; só analytics_storage é autorizado após aceitação.');
