const fs = require('node:fs');
const path = require('node:path');
const { after, before, beforeEach, test } = require('node:test');
const {
  assertFails,
  assertSucceeds,
  initializeTestEnvironment,
} = require('@firebase/rules-unit-testing');
const { doc, getDoc, setDoc, updateDoc } = require('firebase/firestore');

const PROJECT_ID = 'demo-golanguages-security';
const STUDENT_UID = 'student-1';
let testEnv;

before(async () => {
  testEnv = await initializeTestEnvironment({
    projectId: PROJECT_ID,
    firestore: {
      rules: fs.readFileSync(path.resolve(__dirname, '../../firestore.rules'), 'utf8'),
    },
  });
});

beforeEach(async () => testEnv.clearFirestore());
after(async () => testEnv.cleanup());

function studentDb(uid = STUDENT_UID) {
  return testEnv.authenticatedContext(uid, { email: `${uid}@example.com` }).firestore();
}

function adminDb() {
  return testEnv.authenticatedContext('admin-1', {
    email: 'admin@golanguages.com',
    admin: true,
  }).firestore();
}

test('visitantes e alunos não podem ler nem substituir admin/dados', async () => {
  const adminDoc = doc(testEnv.unauthenticatedContext().firestore(), 'admin/dados');
  await assertFails(getDoc(adminDoc));
  await assertFails(setDoc(doc(studentDb(), 'admin/dados'), { cursos: [], alunos: [] }));
  await assertSucceeds(setDoc(doc(adminDb(), 'admin/dados'), { cursos: [] }));
});

test('public/config é público para leitura, mas apenas admins podem alterá-lo', async () => {
  const visitante = testEnv.unauthenticatedContext().firestore();
  await assertSucceeds(getDoc(doc(visitante, 'public/config')));
  await assertFails(setDoc(doc(studentDb(), 'public/config'), { precos: {} }));
  await assertSucceeds(setDoc(doc(adminDb(), 'public/config'), { precos: {} }));
});

test('aluno só cria e lê o próprio perfil e não pode promover-se ou editar campos privilegiados', async () => {
  const db = studentDb();
  const ownProfile = doc(db, `students/${STUDENT_UID}`);
  await assertSucceeds(setDoc(ownProfile, {
    uid: STUDENT_UID,
    email: `${STUDENT_UID}@example.com`,
    nome: 'Aluno',
    telefone: '900000000',
  }));
  await assertSucceeds(getDoc(ownProfile));
  await assertFails(getDoc(doc(db, 'students/student-2')));
  await assertFails(setDoc(doc(db, 'students/student-2'), {
    uid: 'student-2', email: 'student-2@example.com', nome: 'Outro',
  }));
  await assertFails(updateDoc(ownProfile, { comprados: ['curso-1'] }));
  await assertFails(updateDoc(ownProfile, { email: 'outro@example.com' }));
});

test('aluno cria reserva pendente própria, mas não aprova nem altera reservas', async () => {
  const db = studentDb();
  const ownBooking = doc(db, 'bookings/booking-1');
  await assertSucceeds(setDoc(ownBooking, {
    uid: STUDENT_UID,
    estado: 'aguarda_horario',
    pagamentoEstado: 'aguarda_liberacao',
  }));
  await assertFails(setDoc(doc(db, 'bookings/booking-2'), {
    uid: STUDENT_UID, estado: 'agendada', pagamentoEstado: 'Pago',
  }));
  await assertFails(updateDoc(ownBooking, { pagamentoEstado: 'Pago', estado: 'agendada' }));
  await assertFails(getDoc(doc(db, 'bookings/other-booking')));
});

test('aluno só cria pedidos associados ao próprio UID', async () => {
  const db = studentDb();
  await assertSucceeds(setDoc(doc(db, 'requests/request-1'), {
    uid: STUDENT_UID, tipo: 'domicilio', estado: 'pendente', morada: 'Rua privada',
  }));
  await assertFails(setDoc(doc(db, 'requests/request-2'), {
    uid: 'student-2', tipo: 'domicilio', estado: 'pendente',
  }));
  await assertFails(getDoc(doc(db, 'requests/other-request')));
});
