const { onRequest } = require('firebase-functions/v2/https');
const { defineSecret } = require('firebase-functions/params');
const { initializeApp } = require('firebase-admin/app');
const { getAuth } = require('firebase-admin/auth');

initializeApp();
const githubToken = defineSecret('GITHUB_TOKEN');
const MAX_UPLOAD_BYTES = 30 * 1024 * 1024;
const OWNER = process.env.GITHUB_OWNER || 'languagego3-boop7';
const REPO = process.env.GITHUB_REPO || 'GOLANGUAGE202030';
const BRANCH = process.env.GITHUB_BRANCH || 'main';

function reply(res, status, body) {
  res.set('Cache-Control', 'no-store');
  res.status(status).json(body);
}
function cleanName(value) {
  return String(value || 'ficheiro').normalize('NFKD').replace(/[\\u0300-\\u036f]/g, '')
    .replace(/[^a-zA-Z0-9._-]+/g, '-').replace(/^-+|-+$/g, '').slice(0, 100) || 'ficheiro';
}
function encodePath(path) { return path.split('/').map(encodeURIComponent).join('/'); }
async function githubRequest(path, options = {}) {
  const response = await fetch(`https://api.github.com/repos/${OWNER}/${REPO}/contents/${encodePath(path)}`, {
    ...options,
    headers: {
      Accept: 'application/vnd.github+json',
      Authorization: `Bearer ${githubToken.value()}`,
      'X-GitHub-Api-Version': '2022-11-28',
      ...(options.headers || {}),
    },
  });
  const json = await response.json().catch(() => ({}));
  if (!response.ok) {
    const error = new Error(json.message || `GitHub respondeu ${response.status}.`);
    error.status = response.status;
    throw error;
  }
  return json;
}
async function isAdmin(decoded) {
  return decoded.admin === true;
}
async function verifyAdmin(req) {
  const header = String(req.get('authorization') || '');
  const match = header.match(/^Bearer (.+)$/i);
  if (!match) throw Object.assign(new Error('Sessão Firebase necessária.'), { status: 401 });
  const decoded = await getAuth().verifyIdToken(match[1]);
  if (!(await isAdmin(decoded))) throw Object.assign(new Error('Apenas o administrador pode publicar cursos.'), { status: 403 });
}

exports.githubCourseSync = onRequest({
  region: 'us-central1',
  secrets: [githubToken],
  memory: '1GiB',
  timeoutSeconds: 300,
  maxInstances: 2,
}, async (req, res) => {
  if (req.method !== 'POST') return reply(res, 405, { error: 'Método não permitido.' });
  try {
    await verifyAdmin(req);
    const action = String(req.query.action || '');
    if (action === 'upload') {
      const data = req.rawBody || Buffer.alloc(0);
      if (!data.length) return reply(res, 400, { error: 'O ficheiro está vazio.' });
      if (data.length > MAX_UPLOAD_BYTES) return reply(res, 413, { error: 'O limite de upload é 30 MB por ficheiro.' });
      const courseId = cleanName(req.query.courseId);
      const tipo = ['video', 'audio', 'pdf'].includes(String(req.query.tipo)) ? String(req.query.tipo) : 'video';
      const filename = `${Date.now()}-${cleanName(req.query.filename)}`;
      const path = `media/cursos/${courseId}/${tipo}/${filename}`;
      await githubRequest(path, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ message: `Adicionar ${tipo} do curso ${courseId}`, content: data.toString('base64'), branch: BRANCH }),
      });
      return reply(res, 200, { url: `https://raw.githubusercontent.com/${OWNER}/${REPO}/${encodeURIComponent(BRANCH)}/${path.split('/').map(encodeURIComponent).join('/')}`, path });
    }
    if (action === 'catalog') {
      const body = req.body || {};
      const cursos = Array.isArray(body.cursos) ? body.cursos : null;
      if (!cursos) return reply(res, 400, { error: 'Catálogo de cursos inválido.' });
      if (cursos.some((c) => !String(c.nome || '').trim() || !String(c.descricao || '').trim())) {
        return reply(res, 400, { error: 'Todos os cursos precisam de nome e descrição antes da publicação.' });
      }
      if (cursos.some((c) => (Array.isArray(c.aulas) ? c.aulas : []).some((a) => String(a.url || '').startsWith('data:')))) {
        return reply(res, 400, { error: 'Reenvie as aulas antigas como ficheiros para o GitHub antes da publicação.' });
      }
      const manifest = {
        schemaVersion: 1,
        updatedAt: new Date().toISOString(),
        courses: cursos.map((c) => ({
          id: c.id, nome: c.nome, descricao: c.descricao || '', preco: Number(c.preco) || 0,
          img: c.img || '', modulos: Number(c.modulos) || 0, tipoConteudo: c.tipoConteudo || 'misto',
          estado: c.estado || 'Ativo',
          aulas: (Array.isArray(c.aulas) ? c.aulas : []).map((a) => ({
            id: a.id, titulo: a.titulo || '', descricao: a.descricao || '', tipo: a.tipo || 'video',
            duracao: a.duracao || '', url: a.url || '', estado: a.estado || 'Publicada',
          })),
        })),
      };
      const content = Buffer.from(JSON.stringify(manifest, null, 2));
      if (content.length > 1024 * 1024) return reply(res, 413, { error: 'O catálogo excede 1 MB.' });
      const path = 'catalog/cursos.json';
      let sha;
      try { sha = (await githubRequest(path, { method: 'GET' })).sha; }
      catch (e) { if (e.status !== 404) throw e; }
      await githubRequest(path, {
        method: 'PUT', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ message: 'Atualizar catálogo de cursos', content: content.toString('base64'), branch: BRANCH, ...(sha ? { sha } : {}) }),
      });
      return reply(res, 200, { path, url: `https://raw.githubusercontent.com/${OWNER}/${REPO}/${encodeURIComponent(BRANCH)}/${path}` });
    }
    return reply(res, 400, { error: 'Ação desconhecida.' });
  } catch (error) {
    console.error('[githubCourseSync]', error);
    const status = error.status || (String(error.code || '').startsWith('auth/') ? 401 : 500);
    return reply(res, status, { error: status >= 500 ? 'Não foi possível publicar no GitHub. Verifique token, branch e permissões do repositório.' : error.message });
  }
});
