// Google Consent Mode v2: estado seguro antes de qualquer SDK de medição.
// Este ficheiro não carrega gtag.js nem envia pedidos de Analytics.
(() => {
  'use strict';

  window.dataLayer = window.dataLayer || [];
  window.gtag = window.gtag || function gtag() { window.dataLayer.push(arguments); };

  const negado = Object.freeze({
    ad_storage: 'denied',
    ad_user_data: 'denied',
    ad_personalization: 'denied',
    analytics_storage: 'denied',
  });

  // Deve executar no <head>, antes de Firebase Analytics ou qualquer tag.
  window.gtag('consent', 'default', negado);

  window.goSchoolUpdateGoogleConsent = escolha => {
    const consentimento = escolha === 'analytics'
      ? { ...negado, analytics_storage: 'granted' }
      : negado;
    window.gtag('consent', 'update', consentimento);
  };
})();
