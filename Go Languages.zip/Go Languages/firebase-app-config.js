// Configuração pública do projeto Firebase, partilhada pelos módulos do site.
// Estes valores identificam o projeto e não são credenciais administrativas.
export const firebaseConfig = {
  apiKey: "AIzaSyDYDxjPCDV95JNhLuT2N898PltpvhN-HnQ",
  authDomain: "go-language0.firebaseapp.com",
  projectId: "go-language0",
  storageBucket: "go-language0.firebasestorage.app",
  messagingSenderId: "357336999460",
  appId: "1:357336999460:web:206025b162c83c96b81ab1",
  measurementId: "G-SNWFKQC88H"
};
