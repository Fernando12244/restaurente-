# Segurança e migração do Firestore

`admin/dados` contém dados privados e só aceita utilizadores com a custom claim `admin: true`. O site público lê apenas a projeção com campos permitidos em `public/config`. Perfis, reservas e pedidos ficam nas coleções `students/{uid}`, `bookings/{id}` e `requests/{id}`; as regras limitam leituras aos administradores e ao UID proprietário.

## Preparar o projeto Firebase

Execute os comandos numa máquina de confiança, dentro de `functions`, com Firebase Admin SDK autorizado ao projeto `go-language0`. Use Application Default Credentials ou defina `GOOGLE_APPLICATION_CREDENTIALS` para um ficheiro de credenciais que não esteja no repositório.

```powershell
npm install
npm run set-admin-claim -- admin@golanguages.com
npm run migrate-private-data
```

Repita `set-admin-claim` para cada conta administrativa autorizada. A migração associa os registos existentes às contas Firebase Auth pelo e-mail, cria os documentos por UID e gera `public/config` com uma lista explícita de campos públicos. O documento legado `admin/dados` é mantido, mas deixa de ser legível por alunos e visitantes.

Depois da migração, publique as regras e o site:

```powershell
firebase deploy --only firestore:rules,hosting
```

Os administradores devem terminar a sessão e entrar novamente para receber a custom claim. As páginas removem a antiga chave local `gl_admin_v4`; dados privados deixam de ser guardados nessa cache.

## Verificação antes de produção

Execute a suíte automatizada das regras com o emulador Firestore ativo. A partir da raiz do projeto:

```powershell
cd functions
npm install
cd ..
firebase emulators:exec --only firestore "npm --prefix functions run test:rules"
```

Os testes cobrem leituras públicas/privadas, isolamento por UID, criação de perfil próprio, tentativas de aprovar reservas e acesso administrativo com custom claim.

- Sem sessão, uma leitura de `admin/dados`, `students`, `bookings` ou `requests` deve ser recusada; `public/config` deve ser legível.
- Um aluno deve ler apenas o documento de perfil, reservas e pedidos associados ao próprio UID.
- Um aluno não deve conseguir alterar o estado de pagamento, aprovação ou dados de outro aluno.
- Uma conta com a custom claim `admin: true` deve conseguir abrir o painel e gerir os dados.

Não publique as regras antes de executar a atribuição das claims e a migração: sem a claim, o painel administrativo será corretamente recusado pelas regras.
