(() => {
  'use strict';
  const KEY = 'gl_cookie_consent_v1';
  const css = document.createElement('link');
  css.rel = 'stylesheet';
  css.href = new URL('cookie-consent.css', document.currentScript.src).href;
  document.head.appendChild(css);
  const readChoice = () => {
    try { return localStorage.getItem(KEY); } catch { return null; }
  };
  const announceChoice = value => {
    window.goSchoolUpdateGoogleConsent?.(value);
    window.dispatchEvent(new CustomEvent('gl:cookie-consent-change', { detail: { choice: value } }));
  };
  let banner;

  function buildBanner() {
    if (banner) return banner;
    banner = document.createElement('section');
    banner.id = 'gl-cookie-banner';
    banner.setAttribute('role', 'region');
    banner.setAttribute('aria-label', 'Preferências de cookies');
    banner.innerHTML = `
      <h2 class="gl-cookie-title">A sua privacidade importa</h2>
      <p>Usamos tecnologias necessárias para manter o site e a sua conta. O Analytics só é activado se escolher “Aceitar Analytics”. Leia a <a href="cookies.html" target="_blank" rel="noopener noreferrer">Política de Cookies</a> para saber mais.</p>
      <div class="gl-cookie-actions">
        <button type="button" data-choice="essential">Só essenciais</button>
        <button type="button" data-choice="analytics">Aceitar Analytics</button>
      </div>`;
    banner.addEventListener('click', event => {
      const button = event.target.closest('button[data-choice]');
      if (!button) return;
      const choice = button.dataset.choice;
      try { localStorage.setItem(KEY, choice); } catch {}
      banner.hidden = true;
      announceChoice(choice);
    });
    document.body.appendChild(banner);
    return banner;
  }

  function managePreferences() {
    const panel = buildBanner();
    panel.hidden = false;
    panel.querySelector('button[data-choice="essential"]')?.focus();
  }

  window.gerirPreferenciasCookies = managePreferences;
  window.lerPreferenciaCookies = readChoice;

  function initialize() {
    const choice = readChoice();
    if (choice !== 'essential' && choice !== 'analytics') managePreferences();
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', initialize, { once: true });
  else initialize();

  window.addEventListener('storage', event => {
    if (event.key === KEY) announceChoice(event.newValue === 'analytics' ? 'analytics' : 'essential');
  });
})();
