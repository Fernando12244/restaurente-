/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ['./*.html', './*.js', './*.mjs'],
  darkMode: 'class',
  safelist: [
    { pattern: /^(bg|text|border|ring|from|via|to)-(roxo|laranja)(-(50|100|200|300|400|500|600|700|800|900))?$/ },
  ],
  theme: {
    extend: {
      colors: {
        roxo: { DEFAULT: '#4A148C', 50: '#f7f3fb', 100: '#ebe0f6', 200: '#d6bdee', 600: '#5e1aa6', 700: '#4A148C', 800: '#3a0f6e', 900: '#2b0a52' },
        laranja: { DEFAULT: '#c25600', 50: '#fff8f0', 100: '#ffedd5', 200: '#fed7aa', 500: '#F57C00', 600: '#ea6c00', 700: '#c25600' },
      },
      fontFamily: { sans: ['Inter', 'system-ui', 'sans-serif'] },
      boxShadow: {
        soft: '0 1px 2px rgba(16,24,40,.04), 0 1px 3px rgba(16,24,40,.06)',
        card: '0 1px 3px rgba(16,24,40,.06), 0 8px 24px -12px rgba(16,24,40,.12)',
        pop: '0 30px 60px -20px rgba(74,20,140,.35)',
        tab: '0 -4px 24px -8px rgba(74,20,140,.18)',
      },
      keyframes: {
        fadeUp: { '0%': { opacity: 0, transform: 'translateY(12px)' }, '100%': { opacity: 1, transform: 'none' } },
        fadeIn: { '0%': { opacity: 0 }, '100%': { opacity: 1 } },
        shake: { '0%,100%': { transform: 'translateX(0)' }, '25%': { transform: 'translateX(-6px)' }, '75%': { transform: 'translateX(6px)' } },
        slideIn: { '0%': { opacity: 0, transform: 'translateX(30px)' }, '100%': { opacity: 1, transform: 'none' } },
        slideUp: { '0%': { opacity: 0, transform: 'translateY(24px) scale(.98)' }, '100%': { opacity: 1, transform: 'none' } },
      },
      animation: {
        'fade-up': 'fadeUp .5s ease both',
        'fade-in': 'fadeIn .4s ease both',
        shake: 'shake .35s ease',
        'slide-in': 'slideIn .3s cubic-bezier(.4,0,.2,1)',
        'slide-up': 'slideUp .28s cubic-bezier(.4,0,.2,1)',
      },
    },
  },
};
