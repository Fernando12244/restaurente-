/**
 * Controlo de consentimento do Firebase Analytics, separado do SDK para
 * permitir verificar o comportamento sem carregar serviços externos.
 */
export function criarControladorConsentimentoAnalytics({ app, carregarSdk }) {
  let sdk = null;
  let instancia = null;
  let ativo = false;
  let fila = Promise.resolve();

  function actualizar(escolha) {
    fila = fila.catch(() => {}).then(async () => {
      if (escolha !== 'analytics') {
        if (instancia && sdk) {
          sdk.setAnalyticsCollectionEnabled(instancia, false);
          sdk.resetAnalyticsData(instancia);
          instancia = null;
        }
        ativo = false;
        return;
      }

      if (!sdk) sdk = await carregarSdk();
      if (!(await sdk.isSupported())) {
        ativo = false;
        return;
      }
      if (!instancia) instancia = sdk.getAnalytics(app);
      sdk.setAnalyticsCollectionEnabled(instancia, true);
      ativo = true;
    });
    return fila;
  }

  return {
    actualizar,
    estado: () => ({ carregado: Boolean(sdk), activo: ativo, instancia }),
  };
}
