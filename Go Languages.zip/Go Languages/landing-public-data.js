// A landing page precisa apenas do catálogo público, sem Auth ou Analytics.
import { initializeApp } from "https://www.gstatic.com/firebasejs/12.8.0/firebase-app.js";
import { doc, getDoc, getFirestore } from "https://www.gstatic.com/firebasejs/12.8.0/firebase-firestore.js";
import { firebaseConfig } from './firebase-app-config.js';

const app = initializeApp(firebaseConfig, 'go-school-landing');
const db = getFirestore(app);

export async function carregarConfiguracaoPublica() {
  const snapshot = await getDoc(doc(db, 'public', 'config'));
  return snapshot.exists() ? snapshot.data() : null;
}
